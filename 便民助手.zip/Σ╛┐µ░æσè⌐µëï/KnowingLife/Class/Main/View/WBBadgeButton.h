//
//  WBBadgeButton.h
//  XinWeibo
//
//  Created by tanyang on 14-10-7.
//  Copyright (c) 2014年 tany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WBBadgeButton : UIButton
@property (nonatomic, copy) NSString *badgeValue;
@end
