//
//  KLDealAnnotation.m
//  KnowingLife
//
//  Created by tanyang on 14/11/6.
//  Copyright (c) 2014年 tany. All rights reserved.
//

#import "KLDealAnnotation.h"


@implementation KLDealAnnotation

@end
