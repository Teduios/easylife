//
//  KLBaseCity.h
//  KnowingLife
//
//  Created by tanyang on 14/11/1.
//  Copyright (c) 2014年 tany. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KLBaseModel : NSObject
// 名字
@property (nonatomic, copy) NSString *name;
@end
