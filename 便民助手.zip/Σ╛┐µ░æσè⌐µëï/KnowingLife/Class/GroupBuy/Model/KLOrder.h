//
//  TGOrder.h
//  团购
//
//  Created by apple on 13-11-11.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "KLBaseModel.h"

@interface KLOrder : KLBaseModel
@property (nonatomic, assign) int index;
@end
