//
//  KLSubCategorie.h
//  KnowingLife
//
//  Created by tanyang on 14/11/3.
//  Copyright (c) 2014年 tany. All rights reserved.
//

#import "KLBaseCategory.h"

@interface KLSubCategorie : KLBaseCategory
@property (nonatomic, strong) NSArray *subcategories;
@end
