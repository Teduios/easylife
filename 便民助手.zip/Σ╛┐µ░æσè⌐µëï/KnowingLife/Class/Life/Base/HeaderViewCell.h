//
//  HeaderViewCell.h
//  KnowingLife
//
//  Created by tanyang on 14/10/29.
//  Copyright (c) 2014年 tany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeaderViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@end
