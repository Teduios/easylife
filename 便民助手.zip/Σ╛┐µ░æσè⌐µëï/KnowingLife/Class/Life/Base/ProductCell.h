//
//  ProductCell.h
//  Lottery Ticket
//
//  Created by tanyang on 14-9-25.
//  Copyright (c) 2014年 tany. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ProductItem;
@interface ProductCell : UICollectionViewCell
@property (nonatomic, strong) ProductItem *item;
@end
