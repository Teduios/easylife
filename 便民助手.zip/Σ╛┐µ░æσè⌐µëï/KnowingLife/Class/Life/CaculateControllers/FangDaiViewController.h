//
//  FangDaiViewController.h
//  FangDaiDemo
//
//  Created by baiteng-5 on 14-1-6.
//  Copyright (c) 2014年 org.baiteng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FangDaiViewController : UIViewController<UITextFieldDelegate,UIGestureRecognizerDelegate,UITableViewDataSource,UITableViewDelegate>

@end
