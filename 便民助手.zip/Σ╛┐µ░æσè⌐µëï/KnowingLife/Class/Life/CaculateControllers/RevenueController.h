//
//  RevenueController.h
//  KnowingLife
//
//  Created by tanyang on 14/10/31.
//  Copyright (c) 2014年 tany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RevenueController : UITableViewController

@end
