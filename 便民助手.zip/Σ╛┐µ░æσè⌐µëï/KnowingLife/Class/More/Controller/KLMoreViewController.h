//
//  KLMoreViewController.h
//  KnowingLife
//
//  Created by tanyang on 14/10/28.
//  Copyright (c) 2014年 tany. All rights reserved.
//

#import <UIKit/UIKit.h>

@class KLWeatherInfo;
@interface KLMoreViewController : UITableViewController
@property (nonatomic, strong) KLWeatherInfo *weatherInfo;
@end
