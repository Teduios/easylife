#ifndef __MJConst__M__
#define __MJConst__M__

#endif