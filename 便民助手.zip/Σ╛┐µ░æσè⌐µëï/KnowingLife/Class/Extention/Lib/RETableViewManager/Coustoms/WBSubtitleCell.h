//
//  WBDetailLableCell.h
//  XinWeibo
//
//  Created by tanyang on 14/10/23.
//  Copyright (c) 2014年 tany. All rights reserved.
//

#import "RETableViewCell.h"
#import "WBSubtitleItem.h"

@interface WBSubtitleCell : RETableViewCell
@property (nonatomic, strong) WBSubtitleItem *item;
@end
